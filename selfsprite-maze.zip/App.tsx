
import React, { useState, useCallback, useRef, useEffect } from 'react';
import { AppState, IPlayerConfig, SpriteSource, CHARACTER_TYPES, MOTION_TYPES, GENDER_TYPES, Level } from './types';
import { generateCharacterAnimation } from './services/geminiService';
import { fileToBase64, sliceSpriteSheet } from './services/imageService';
import FightScreen from './components/FightScreen';
import GenerationProgress from './components/GenerationProgress';
import InstructionsScreen from './components/InstructionsScreen';
import PlayerSetupScreen from './components/PlayerSetupScreen';
import PreGameShowcase from './components/PreGameShowcase';
import { generateLevel } from './services/levelGenerator';

const App: React.FC = () => {
    const [appState, setAppState] = useState<AppState>(AppState.INSTRUCTIONS);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    
    // Configs
    const [p1Config, setP1Config] = useState<IPlayerConfig | null>(null);
    const [p2Config, setP2Config] = useState<IPlayerConfig | null>(null);

    // Final Sprites
    const [p1Sprites, setP1Sprites] = useState<string[] | null>(null);
    const [p2Sprites, setP2Sprites] = useState<string[] | null>(null);

    // Generation State
    const [p1Progress, setP1Progress] = useState<string[]>([]);
    const [p2Progress, setP2Progress] = useState<string[]>([]);
    const abortControllerRef = useRef<AbortController | null>(null);
    const [p1FullSheet, setP1FullSheet] = useState<string | null>(null);
    const [p2FullSheet, setP2FullSheet] = useState<string | null>(null);
    const [isGenerationComplete, setIsGenerationComplete] = useState<boolean>(false);
    const [defaultP1File, setDefaultP1File] = useState<File | null>(null);
    const [defaultP2File, setDefaultP2File] = useState<File | null>(null);
    const [p1TotalFrames, setP1TotalFrames] = useState(9);
    const [p2TotalFrames, setP2TotalFrames] = useState(9);
    const [p1Cols, setP1Cols] = useState(3);
    const [p2Cols, setP2Cols] = useState(3);
    const [p1AnalysisText, setP1AnalysisText] = useState<string | null>(null);
    const [p2AnalysisText, setP2AnalysisText] = useState<string | null>(null);


    // Game State
    const [currentLevelIndex, setCurrentLevelIndex] = useState(0);
    const [currentLevelData, setCurrentLevelData] = useState<Level | null>(null);

    // Error State
    const [errorMessage, setErrorMessage] = useState<string | null>(null);

    useEffect(() => {
        const loadDefaultSprites = async () => {
            try {
                const p1Response = await fetch('/sprites/1.png');
                if (!p1Response.ok) throw new Error('Failed to load 1.png');
                const p1Blob = await p1Response.blob();
                setDefaultP1File(new File([p1Blob], "1.png", { type: "image/png" }));

                const p2Response = await fetch('/sprites/2.png');
                if (!p2Response.ok) throw new Error('Failed to load 2.png');
                const p2Blob = await p2Response.blob();
                setDefaultP2File(new File([p2Blob], "2.png", { type: "image/png" }));
            } catch (error) {
                console.warn("Could not load default sprites. Please upload manually.", error);
            }
        };
        loadDefaultSprites();
    }, []);

     // Effect to generate a new level when the state changes to FightScreen or the level index is incremented
    useEffect(() => {
        if (appState === AppState.FIGHT_SCREEN) {
            setCurrentLevelData(generateLevel(currentLevelIndex));
        }
    }, [appState, currentLevelIndex]);

    
    const handleStartGeneration = useCallback(async (p1: IPlayerConfig, p2: IPlayerConfig) => {
        if (!p1.file || !p2.file) {
            setErrorMessage("Both players must provide a file.");
            setAppState(AppState.ERROR);
            return;
        }
        
        const controller = new AbortController();
        abortControllerRef.current = controller;

        setIsLoading(true);
        setAppState(AppState.GENERATING);
        setErrorMessage(null);
        setP1Progress([]);
        setP2Progress([]);
        setIsGenerationComplete(false);
        setP1AnalysisText(null);
        setP2AnalysisText(null);
        
        // Set initial frame counts
        setP1TotalFrames(p1.source === SpriteSource.UPLOAD ? p1.spriteSheetCols * p1.spriteSheetRows : 9);
        setP2TotalFrames(p2.source === SpriteSource.UPLOAD ? p2.spriteSheetCols * p2.spriteSheetRows : 9);


        try {
            const getPlayerSprites = async (config: IPlayerConfig, onProgress: (sprites: string[]) => void): Promise<{ fullSheet: string | null; sprites: string[]; cols: number; rows: number; analysisText: string | null }> => {
                if (!config.file) throw new Error("Missing file for sprite processing.");

                if (config.source === SpriteSource.UPLOAD) {
                    const sprites = await sliceSpriteSheet(config.file, config.spriteSheetCols, config.spriteSheetRows);
                    onProgress(sprites);
                    return { fullSheet: null, sprites, cols: config.spriteSheetCols, rows: config.spriteSheetRows, analysisText: null };
                } else {
                    const base64 = await fileToBase64(config.file);
                    const result = await generateCharacterAnimation(
                        base64,
                        config.file.type,
                        config.gender,
                        config.character,
                        config.motionType,
                        config.frameCount,
                        onProgress,
                        controller.signal
                    );
                    return { fullSheet: result.fullSheet, sprites: result.sprites, cols: result.cols, rows: result.rows, analysisText: result.analysisText };
                }
            };

            const [p1Result, p2Result] = await Promise.all([
                getPlayerSprites(p1, (sprites) => setP1Progress([...sprites])),
                getPlayerSprites(p2, (sprites) => setP2Progress([...sprites])),
            ]);
            
            if (controller.signal.aborted) return;

            setP1TotalFrames(p1Result.cols * p1Result.rows);
            setP1Cols(p1Result.cols);
            setP2TotalFrames(p2Result.cols * p2Result.rows);
            setP2Cols(p2Result.cols);

            setP1FullSheet(p1Result.fullSheet);
            setP2FullSheet(p2Result.fullSheet);
            setP1Sprites(p1Result.sprites);
            setP2Sprites(p2Result.sprites);
            setP1AnalysisText(p1Result.analysisText);
            setP2AnalysisText(p2Result.analysisText);
            setIsGenerationComplete(true);

        } catch (error) {
            if (error instanceof Error && error.name === 'AbortError') return;
            console.error(error);
            const message = error instanceof Error ? error.message : "An unknown error occurred.";
            setErrorMessage(`ERROR: ${message}`);
            setAppState(AppState.ERROR);
        } finally {
            // Loading is conceptually finished from the user's perspective here.
        }
    }, []);

    const handleProceedToShowcase = () => {
        setAppState(AppState.PRE_GAME_SHOWCASE);
    };

    const handleP1SetupComplete = (config: IPlayerConfig) => {
        setP1Config(config);
        setAppState(AppState.SETUP_P2);
    };

    const handleP2SetupComplete = (config: IPlayerConfig) => {
        setP2Config(config);
        if (p1Config) {
            handleStartGeneration(p1Config, config);
        } else {
            setErrorMessage("Player 1 configuration is missing.");
            setAppState(AppState.ERROR);
        }
    };


    const handleReset = () => {
        setAppState(AppState.INSTRUCTIONS);
        setIsLoading(false);
        setP1Sprites(null);
        setP2Sprites(null);
        setP1Progress([]);
        setP2Progress([]);
        setP1Config(null);
        setP2Config(null);
        setErrorMessage(null);
        setCurrentLevelIndex(0);
        setCurrentLevelData(null);
        setP1FullSheet(null);
        setP2FullSheet(null);
        setIsGenerationComplete(false);
        setP1AnalysisText(null);
        setP2AnalysisText(null);
        setP1TotalFrames(9);
        setP2TotalFrames(9);
        setP1Cols(3);
        setP2Cols(3);
    };

    const handleCancelGeneration = () => {
        abortControllerRef.current?.abort();
        handleReset();
    };

    const handleNextLevel = () => {
        setCurrentLevelIndex(prev => prev + 1);
    };

    const handleRegenerateLevel = () => {
        setCurrentLevelData(generateLevel(currentLevelIndex));
    };

    const getDefaultConfig = (player: 1 | 2): IPlayerConfig => ({
        source: SpriteSource.UPLOAD,
        file: player === 1 ? defaultP1File : defaultP2File,
        gender: GENDER_TYPES[player === 1 ? 0 : 1],
        character: CHARACTER_TYPES[player === 1 ? 0 : 1],
        motionType: MOTION_TYPES[player === 1 ? 0 : 1],
        frameCount: 4,
        spriteSheetCols: 3,
        spriteSheetRows: 3,
    });

    const renderContent = () => {
        switch (appState) {
            case AppState.INSTRUCTIONS:
                return <InstructionsScreen onContinue={() => setAppState(AppState.SETUP_P1)} />;
            case AppState.SETUP_P1:
                 return <PlayerSetupScreen 
                    key="p1"
                    playerNumber={1} 
                    onComplete={handleP1SetupComplete} 
                    initialConfig={getDefaultConfig(1)}
                 />;
            case AppState.SETUP_P2:
                 return <PlayerSetupScreen 
                    key="p2"
                    playerNumber={2} 
                    onComplete={handleP2SetupComplete}
                    initialConfig={getDefaultConfig(2)}
                />;
            case AppState.GENERATING:
                return (
                    <GenerationProgress 
                        p1Progress={p1Progress}
                        p1TotalFrames={p1TotalFrames}
                        p1Cols={p1Cols}
                        p1FullSheet={p1FullSheet}
                        p1Source={p1Config?.source ?? SpriteSource.UPLOAD}
                        p1AnalysisText={p1AnalysisText}
                        p2Progress={p2Progress}
                        p2TotalFrames={p2TotalFrames}
                        p2Cols={p2Cols}
                        p2FullSheet={p2FullSheet}
                        p2Source={p2Config?.source ?? SpriteSource.UPLOAD}
                        p2AnalysisText={p2AnalysisText}
                        isComplete={isGenerationComplete}
                        onCancel={handleCancelGeneration}
                        onProceed={handleProceedToShowcase}
                    />
                );
            case AppState.PRE_GAME_SHOWCASE:
                 if (p1Sprites && p2Sprites) {
                     return <PreGameShowcase
                        p1Sprites={p1Sprites}
                        p2Sprites={p2Sprites}
                        onComplete={() => setAppState(AppState.FIGHT_SCREEN)}
                     />;
                 }
                handleReset(); // Fallback
                return null;

            case AppState.FIGHT_SCREEN:
                 if (p1Sprites && p2Sprites && p1Config && p2Config && currentLevelData) {
                     return <FightScreen 
                        player1={{ sprites: p1Sprites }}
                        player2={{ sprites: p2Sprites }}
                        onReset={handleReset}
                        level={currentLevelData}
                        onNextLevel={handleNextLevel}
                        currentLevelIndex={currentLevelIndex}
                        p1Config={p1Config}
                        p2Config={p2Config}
                        onRegenerateLevel={handleRegenerateLevel}
                     />;
                 }
                // If data is missing, reset or show loader. For now, reset.
                if (p1Sprites && p2Sprites && p1Config && p2Config && !currentLevelData) {
                    return <div>Generating Level...</div>;
                }
                handleReset(); // Fallback
                return null;
            case AppState.ERROR:
                return (
                    <div className="text-center text-[var(--color-foreground)] bg-[var(--color-destructive)]/50 p-8 border-2 border-[var(--color-destructive)] rounded-lg">
                        <h2 className="text-3xl text-[var(--color-destructive)] mb-4">An Error Occurred</h2>
                        <p className="text-[var(--color-muted-foreground)] mb-6">{errorMessage || 'Something went wrong.'}</p>
                        <button onClick={handleReset} className="bg-[var(--color-primary-accent)] text-black px-8 py-3 text-lg border-2 border-black hover:bg-[var(--color-primary-accent-darker)]">
                            TRY AGAIN
                        </button>
                    </div>
                );
            default:
                return <InstructionsScreen onContinue={() => setAppState(AppState.SETUP_P1)} />;
        }
    };

    return (
        <div 
            className="min-h-screen flex flex-col items-center justify-center p-4 sm:p-6 lg:p-8 bg-cover bg-center"
            style={appState === AppState.INSTRUCTIONS ? { 
                backgroundImage: `url('https://firebasestorage.googleapis.com/v0/b/hectasquare-v10.firebasestorage.app/o/bkGnd.webp?alt=media&token=7aacd264-bc5f-4bef-8c5c-462d49d02d28')`,
            } : {}}
        >
            <header className="w-full max-w-4xl text-center mb-8">
                <h1 className="text-3xl sm:text-4xl md:text-5xl text-[var(--color-primary-accent)] tracking-widest inline-block bg-[var(--color-card-background)] px-4 py-2 rounded-md shadow-lg">SELFSPRITE MAZE</h1>
            </header>
            <main className="w-full flex-grow flex items-center justify-center">
                {renderContent()}
            </main>
        </div>
    );
};

export default App;