
import React, { useState, useRef, useEffect } from 'react';
import { CameraIcon, ResetIcon, CheckIcon } from './icons';

interface CameraModalProps {
    onClose: () => void;
    onPhotoTaken: (file: File) => void;
}

const CameraModal: React.FC<CameraModalProps> = ({ onClose, onPhotoTaken }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [capturedImage, setCapturedImage] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const startCamera = async () => {
            try {
                if (stream) {
                    stream.getTracks().forEach(track => track.stop());
                }
                const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
                setStream(mediaStream);
                if (videoRef.current) {
                    videoRef.current.srcObject = mediaStream;
                }
            } catch (err) {
                console.error("Camera access denied:", err);
                setError("Camera access was denied. Please enable camera permissions in your browser settings and refresh the page.");
            }
        };

        if (!capturedImage) {
            startCamera();
        }

        return () => { // Cleanup function
            stream?.getTracks().forEach(track => track.stop());
        };
    }, [capturedImage]);

    const handleTakePhoto = () => {
        if (!videoRef.current || !canvasRef.current) return;
        
        const video = videoRef.current;
        const canvas = canvasRef.current;
        
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;

        const context = canvas.getContext('2d');
        if (context) {
            context.translate(canvas.width, 0);
            context.scale(-1, 1);
            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            setCapturedImage(canvas.toDataURL('image/jpeg'));
            stream?.getTracks().forEach(track => track.stop());
        }
    };

    const handleRetakePhoto = () => {
        setCapturedImage(null);
        setError(null);
    };

    const handleUsePhoto = () => {
        if (!canvasRef.current) return;
        
        canvasRef.current.toBlob((blob) => {
            if (blob) {
                const photoFile = new File([blob], 'selfie.jpg', { type: 'image/jpeg' });
                onPhotoTaken(photoFile);
                onClose();
            }
        }, 'image/jpeg', 0.95);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4">
            <div className="bg-[var(--color-card-background)] border-2 border-[var(--color-border)] rounded-lg p-6 text-white w-full max-w-2xl text-center">
                <h2 className="text-2xl mb-4 text-[var(--color-primary-accent)]">TAKE A SELFIE</h2>
                
                {error && (
                    <div className="text-[var(--color-destructive)] bg-[var(--color-destructive)]/50 p-4 rounded-md mb-4">
                        <p className="font-bold">Error:</p>
                        <p>{error}</p>
                    </div>
                )}

                <div className="relative w-full aspect-video bg-black rounded-md overflow-hidden mb-4">
                    <video 
                        ref={videoRef} 
                        autoPlay 
                        playsInline 
                        className={`w-full h-full object-cover transform scale-x-[-1] ${capturedImage ? 'hidden' : 'block'}`}
                    />
                    {capturedImage && (
                        <img src={capturedImage} alt="Captured selfie" className="w-full h-full object-cover" />
                    )}
                    <canvas ref={canvasRef} className="hidden"></canvas>
                </div>

                <div className="flex flex-col sm:flex-row justify-center gap-4">
                    {!capturedImage ? (
                        <button onClick={handleTakePhoto} disabled={!!error} className="flex-1 bg-[var(--color-secondary-accent)] text-black px-6 py-3 text-sm border-2 border-black hover:bg-[var(--color-secondary-accent-darker)] disabled:bg-gray-700 disabled:text-gray-400 flex items-center justify-center gap-3">
                            <CameraIcon className="w-5 h-5" /> TAKE PHOTO
                        </button>
                    ) : (
                        <>
                            <button onClick={handleRetakePhoto} className="flex-1 bg-[var(--color-primary-accent)] text-black px-6 py-3 text-sm border-2 border-black hover:bg-[var(--color-primary-accent-darker)] flex items-center justify-center gap-3">
                                <ResetIcon className="w-5 h-5" /> RETAKE
                            </button>
                            <button onClick={handleUsePhoto} className="flex-1 bg-[var(--color-tertiary-accent)] text-white px-6 py-3 text-sm border-2 border-black hover:bg-[var(--color-tertiary-accent-darker)] flex items-center justify-center gap-3">
                                <CheckIcon className="w-5 h-5" /> USE THIS PHOTO
                            </button>
                        </>
                    )}
                </div>
                
                 <button onClick={onClose} className="mt-6 text-[var(--color-muted-foreground)] hover:text-white text-xs">CLOSE</button>
            </div>
        </div>
    );
};

export default CameraModal;