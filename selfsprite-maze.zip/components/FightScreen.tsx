import React, { useState, useEffect, useCallback, useRef } from 'react';
import { IPlayerConfig, Level, Position } from '../types';
import { ArrowRightIcon, DownloadIcon, HomeIcon, ResetIcon, UsersIcon } from './icons';
import MobileControls, { MoveDirection } from './MobileControls';
import { createAndDownloadGifZip } from '../services/gifService';

interface PlayerData {
    sprites: string[];
}

interface FightScreenProps {
    player1: PlayerData;
    player2: PlayerData;
    p1Config: IPlayerConfig;
    p2Config: IPlayerConfig;
    onReset: () => void;
    level: Level;
    onNextLevel: () => void;
    currentLevelIndex: number;
    onRegenerateLevel: () => void;
}

// --- Game Constants ---
const GAME_SPEED = 200; // Player and Guard animation speed
const DETECTION_RANGE = 7; // How many tiles away a guard can see the player


// --- AI HELPER FUNCTIONS ---

/**
 * Finds the shortest path between two points using Breadth-First Search.
 * @returns An array of positions from start to end, or an empty array if no path is found.
 */
const findPath = (start: Position, end: Position, layout: number[][], MAZE_ROWS: number, MAZE_COLS: number): Position[] => {
    const queue: Position[] = [start];
    const visited = new Set<string>([`${start.row},${start.col}`]);
    const parentMap = new Map<string, Position>();

    while (queue.length > 0) {
        const current = queue.shift()!;

        if (current.row === end.row && current.col === end.col) {
            // Path found, reconstruct it
            const path: Position[] = [];
            let backtrack: Position | undefined = current;
            while (backtrack) {
                path.unshift(backtrack);
                backtrack = parentMap.get(`${backtrack.row},${backtrack.col}`);
            }
            return path;
        }

        const neighbors = [
            { row: current.row - 1, col: current.col },
            { row: current.row + 1, col: current.col },
            { row: current.row, col: current.col - 1 },
            { row: current.row, col: current.col + 1 },
        ];

        for (const neighbor of neighbors) {
            const { row, col } = neighbor;
            const key = `${row},${col}`;
            if (
                row >= 0 && row < MAZE_ROWS && col >= 0 && col < MAZE_COLS &&
                layout[row][col] !== 1 && !visited.has(key)
            ) {
                visited.add(key);
                parentMap.set(key, current);
                queue.push(neighbor);
            }
        }
    }
    return []; // No path found
};

/**
 * Checks for a clear line of sight between two points.
 */
const hasLineOfSight = (start: Position, end: Position, layout: number[][]): boolean => {
    let x1 = start.col, y1 = start.row;
    let x2 = end.col, y2 = end.row;

    const dx = Math.abs(x2 - x1);
    const dy = Math.abs(y2 - y1);
    const sx = (x1 < x2) ? 1 : -1;
    const sy = (y1 < y2) ? 1 : -1;
    let err = dx - dy;

    while (true) {
        if (layout[y1] && layout[y1][x1] === 1) return false; // Hit a wall
        if ((x1 === x2) && (y1 === y2)) break;

        const e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x1 += sx; }
        if (e2 < dx) { err += dx; y1 += sy; }
    }
    return true;
};

type GuardStatus = 'PATROLLING' | 'CHASING' | 'RETURNING' | 'GOING_TO_EXIT' | 'RETURNING_FROM_EXIT';

interface GuardState extends Position {
    status: GuardStatus;
    patrolPath: Position[];
    patrolPathIndex: number;
    currentPath: Position[];
    frame: number;
    startPos: Position; // The guard's original spawn point.
    visitExitTimer: number; // Ticks until next visit.
}

const FightScreen: React.FC<FightScreenProps> = ({
    player1,
    player2,
    p1Config,
    p2Config,
    onReset,
    level,
    onNextLevel,
    currentLevelIndex,
    onRegenerateLevel
}) => {
    const { maze: mazeLayout, guards: guardPatrolPaths } = level;
    const MAZE_COLS = mazeLayout[0].length;
    const MAZE_ROWS = mazeLayout.length;

    const findStartPosition = useCallback(() => {
        for (let r = 0; r < mazeLayout.length; r++) {
            for (let c = 0; c < mazeLayout[r].length; c++) {
                if (mazeLayout[r][c] === 2) return { row: r, col: c };
            }
        }
        return { row: 1, col: 1 }; // Fallback
    }, [mazeLayout]);
    
    const findEndPosition = useCallback(() => {
        for (let r = 0; r < mazeLayout.length; r++) {
            for (let c = 0; c < mazeLayout[r].length; c++) {
                if (mazeLayout[r][c] === 3) return { row: r, col: c };
            }
        }
        return { row: MAZE_ROWS - 2, col: MAZE_COLS - 2 }; // Fallback
    }, [mazeLayout, MAZE_COLS, MAZE_ROWS]);


    const [playerPos, setPlayerPos] = useState<Position>(() => findStartPosition());
    const [playerFrame, setPlayerFrame] = useState(0);
    const [guards, setGuards] = useState<GuardState[]>(() =>
        guardPatrolPaths.map(path => ({
            row: path[0].row,
            col: path[0].col,
            status: 'PATROLLING',
            patrolPath: path,
            patrolPathIndex: 0,
            currentPath: [],
            frame: 0,
            startPos: path[0],
            // A guard update happens every 2 game ticks (400ms).
            // 10s = 25 ticks, 15s = 37.5 ticks.
            visitExitTimer: Math.floor(25 + Math.random() * 13),
        }))
    );
    const [gameState, setGameState] = useState<'playing' | 'won' | 'lost'>('playing');
    const [downloadingPlayer, setDownloadingPlayer] = useState<'p1' | 'p2' | null>(null);
    const gameLoopRef = useRef<ReturnType<typeof setInterval> | null>(null);
    const gameTickRef = useRef<number>(0);
    const playerPosRef = useRef(playerPos);
    const endPosRef = useRef(findEndPosition());

    useEffect(() => {
        playerPosRef.current = playerPos;
    }, [playerPos]);
    
    useEffect(() => {
        endPosRef.current = findEndPosition();
    }, [findEndPosition]);


    const handlePlayerMove = useCallback((e: KeyboardEvent) => {
        if (gameState !== 'playing') return;

        setPlayerPos(prevPos => {
            let { row, col } = prevPos;
            if (e.key === 'ArrowUp') row--;
            else if (e.key === 'ArrowDown') row++;
            else if (e.key === 'ArrowLeft') col--;
            else if (e.key === 'ArrowRight') col++;

            if (mazeLayout[row] && mazeLayout[row][col] !== 1) {
                return { row, col };
            }
            return prevPos;
        });
    }, [gameState, mazeLayout]);

    const handleMobileMove = useCallback((direction: MoveDirection) => {
        if (gameState !== 'playing') return;

        setPlayerPos(prevPos => {
            let { row, col } = prevPos;
            if (direction === 'up') row--;
            else if (direction === 'down') row++;
            else if (direction === 'left') col--;
            else if (direction === 'right') col++;

            if (mazeLayout[row] && mazeLayout[row][col] !== 1) {
                return { row, col };
            }
            return prevPos;
        });
    }, [gameState, mazeLayout]);

    const restartGame = useCallback(() => {
        setPlayerPos(findStartPosition());
        setGuards(guardPatrolPaths.map(path => ({
            row: path[0].row,
            col: path[0].col,
            status: 'PATROLLING',
            patrolPath: path,
            patrolPathIndex: 0,
            currentPath: [],
            frame: 0,
            startPos: path[0],
            visitExitTimer: Math.floor(25 + Math.random() * 13),
        })));
        setGameState('playing');
    }, [findStartPosition, guardPatrolPaths]);

    // Reset game state when the level changes
    useEffect(() => {
        restartGame();
    }, [level, restartGame]);

    useEffect(() => {
        window.addEventListener('keydown', handlePlayerMove);
        return () => window.removeEventListener('keydown', handlePlayerMove);
    }, [handlePlayerMove]);

    // Main Game Loop
    useEffect(() => {
        if (gameState !== 'playing') {
            if (gameLoopRef.current) clearInterval(gameLoopRef.current);
            return;
        }

        gameLoopRef.current = setInterval(() => {
            gameTickRef.current += 1;
            const currentPlayerPos = playerPosRef.current;
            // Animate Player
            if (player1.sprites.length > 0) {
                setPlayerFrame(f => (f + 1) % player1.sprites.length);
            }

            // Animate and Move Guards with AI (every other tick)
            if (gameTickRef.current % 2 === 0) {
                setGuards(prevGuards => prevGuards.map(guard => {
                    let { status, patrolPath, patrolPathIndex, currentPath, row, col, startPos, visitExitTimer } = guard;
                    const distanceToPlayer = Math.sqrt(Math.pow(col - currentPlayerPos.col, 2) + Math.pow(row - currentPlayerPos.row, 2));
                    const seesPlayer = distanceToPlayer <= DETECTION_RANGE && hasLineOfSight(guard, currentPlayerPos, mazeLayout);

                    // --- STATE TRANSITIONS ---
                    // Highest priority: If player is seen, CHASE.
                    if (seesPlayer) {
                        status = 'CHASING';
                        const chasePath = findPath(guard, currentPlayerPos, mazeLayout, MAZE_ROWS, MAZE_COLS);
                        if (chasePath.length > 1) {
                            currentPath = chasePath.slice(1);
                        }
                    } else {
                        // If we were chasing and lost the player, return to post
                        if (status === 'CHASING' && currentPath.length === 0) {
                            status = 'RETURNING';
                            const returnPath = findPath(guard, startPos, mazeLayout, MAZE_ROWS, MAZE_COLS);
                            currentPath = returnPath.length > 1 ? returnPath.slice(1) : [];
                        }
                        // If returning from a chase is done, resume patrol
                        if (status === 'RETURNING' && currentPath.length === 0) {
                            status = 'PATROLLING';
                            patrolPathIndex = 0;
                        }

                        // NEW LOGIC: Periodically visit the exit
                        if (status === 'PATROLLING') {
                            visitExitTimer--;
                            if (visitExitTimer <= 0) {
                                status = 'GOING_TO_EXIT';
                                const pathToExit = findPath(guard, endPosRef.current, mazeLayout, MAZE_ROWS, MAZE_COLS);
                                currentPath = pathToExit.length > 1 ? pathToExit.slice(1) : [];
                                visitExitTimer = Math.floor(25 + Math.random() * 13); // Reset timer
                            }
                        }

                        // If reached the exit, start returning to post
                        if (status === 'GOING_TO_EXIT' && currentPath.length === 0) {
                            status = 'RETURNING_FROM_EXIT';
                            const pathFromExit = findPath(guard, startPos, mazeLayout, MAZE_ROWS, MAZE_COLS);
                            currentPath = pathFromExit.length > 1 ? pathFromExit.slice(1) : [];
                        }

                        // If returned from exit, resume patrol
                        if (status === 'RETURNING_FROM_EXIT' && currentPath.length === 0) {
                            status = 'PATROLLING';
                            patrolPathIndex = 0;
                        }
                    }

                    // --- MOVEMENT ---
                    let nextPos = { row, col };
                    if (status !== 'PATROLLING' && currentPath.length > 0) {
                         nextPos = currentPath.shift()!;
                    } else if (status === 'PATROLLING') {
                        patrolPathIndex = (patrolPathIndex + 1) % patrolPath.length;
                        nextPos = patrolPath[patrolPathIndex];
                    }

                    return {
                        ...guard,
                        ...nextPos,
                        status,
                        currentPath,
                        patrolPathIndex,
                        visitExitTimer,
                        frame: player2.sprites.length > 0 ? (guard.frame + 1) % player2.sprites.length : 0,
                    };
                }));
            }

        }, GAME_SPEED);

        return () => {
            if (gameLoopRef.current) clearInterval(gameLoopRef.current);
        };
    }, [gameState, player1.sprites.length, player2.sprites.length, mazeLayout, MAZE_ROWS, MAZE_COLS]);

    // Check Win/Loss conditions
    useEffect(() => {
        if (gameState !== 'playing') return;
        if (mazeLayout[playerPos.row][playerPos.col] === 3) {
            setGameState('won');
            return;
        }
        for (const guard of guards) {
            if (playerPos.row === guard.row && playerPos.col === guard.col) {
                setGameState('lost');
                return;
            }
        }
    }, [playerPos, guards, gameState, mazeLayout]);

    const handleDownload = async (player: 'p1' | 'p2') => {
        setDownloadingPlayer(player);
        const sprites = player === 'p1' ? player1.sprites : player2.sprites;
        const config = player === 'p1' ? p1Config : p2Config;
        
        try {
            await createAndDownloadGifZip(sprites, config);
        } catch (error) {
            console.error("Failed to create and download zip file:", error);
            const message = error instanceof Error ? error.message : "An unknown error occurred.";
            alert(`An error occurred while creating the download file: ${message}`);
        } finally {
            setDownloadingPlayer(null);
        }
    };

    const GameOverlay: React.FC<{ status: 'won' | 'lost' }> = ({ status }) => {
        const message = status === 'won' 
            ? `LEVEL ${currentLevelIndex + 1} COMPLETE!`
            : "YOU WERE CAUGHT!";
        
        const color = status === 'won' ? "text-[var(--color-secondary-accent)]" : "text-[var(--color-destructive)]";

        return (
            <div className="absolute inset-0 bg-black bg-opacity-80 flex flex-col items-center justify-center z-20 p-4">
                <p className={`text-3xl md:text-6xl text-center ${color} animate-pulse`}>{message}</p>
                <div className="mt-8 flex flex-col sm:flex-row gap-4">
                    {status === 'won' && (
                         <button 
                            onClick={onNextLevel}
                            className="bg-[var(--color-secondary-accent)] text-black px-6 py-3 text-base border-2 border-black hover:bg-[var(--color-secondary-accent-darker)] active:bg-[var(--color-secondary-accent-darker)] flex items-center justify-center gap-3"
                        >
                            NEXT LEVEL <ArrowRightIcon className="w-5 h-5" />
                        </button>
                    )}
                     {status === 'lost' && (
                        <button 
                            onClick={onRegenerateLevel}
                            className="bg-[var(--color-primary-accent)] text-black px-6 py-3 text-base border-2 border-black hover:bg-[var(--color-primary-accent-darker)] active:bg-[var(--color-primary-accent-darker)] flex items-center justify-center gap-3"
                        >
                            <ResetIcon className="w-5 h-5" /> TRY AGAIN
                        </button>
                    )}
                     <button 
                        onClick={onReset}
                        className="bg-transparent text-white border-2 border-[var(--color-border)] px-6 py-3 text-base hover:bg-[var(--color-border)] active:bg-[var(--color-border)] flex items-center justify-center gap-3"
                    >
                        <UsersIcon className="w-5 h-5" /> NEW CHARACTERS
                    </button>
                </div>
                <div className="mt-6 border-t-2 border-dashed border-[var(--color-border)] pt-6 flex flex-col sm:flex-row gap-4">
                    <button 
                        onClick={() => handleDownload('p1')}
                        disabled={!!downloadingPlayer}
                        className="bg-[var(--color-tertiary-accent)] text-white px-6 py-3 text-sm border-2 border-black hover:bg-[var(--color-tertiary-accent-darker)] active:bg-[var(--color-tertiary-accent-darker)] disabled:bg-gray-700 disabled:cursor-wait flex items-center justify-center gap-3"
                    >
                        <DownloadIcon className="w-5 h-5" /> {downloadingPlayer === 'p1' ? "ZIPPING..." : "DOWNLOAD P1 GIF"}
                    </button>
                     <button 
                        onClick={() => handleDownload('p2')}
                        disabled={!!downloadingPlayer}
                        className="bg-[var(--color-tertiary-accent)] text-white px-6 py-3 text-sm border-2 border-black hover:bg-[var(--color-tertiary-accent-darker)] active:bg-[var(--color-tertiary-accent-darker)] disabled:bg-gray-700 disabled:cursor-wait flex items-center justify-center gap-3"
                    >
                        <DownloadIcon className="w-5 h-5" /> {downloadingPlayer === 'p2' ? "ZIPPING..." : "DOWNLOAD P2 GIF"}
                    </button>
                </div>
            </div>
        );
    };

    const renderMaze = () => {
        const tileWidth = 100 / MAZE_COLS;
        const tileHeight = 100 / MAZE_ROWS;
        const elements: React.ReactNode[] = [];

        for (let r = 0; r < MAZE_ROWS; r++) {
            for (let c = 0; c < MAZE_COLS; c++) {
                 // If it's not a wall, it's a path tile. Render it.
                if (mazeLayout[r][c] !== 1) { 
                    const style: React.CSSProperties = {
                        width: `${tileWidth}%`,
                        height: `${tileHeight}%`,
                        left: `${c * tileWidth}%`,
                        top: `${r * tileHeight}%`,
                        backgroundColor: 'white', // The path is white
                        position: 'absolute'
                    };
                    elements.push(<div key={`path-${r}-${c}`} style={style} />);
                }

                // Render the exit on top of the path tile.
                if (mazeLayout[r][c] === 3) {
                    elements.push(
                        <div
                            key={`exit-${r}-${c}`}
                            className="absolute"
                            style={{
                                backgroundColor: 'var(--color-secondary-accent)',
                                width: `${tileWidth}%`,
                                height: `${tileHeight}%`,
                                left: `${c * tileWidth}%`,
                                top: `${r * tileHeight}%`,
                                boxShadow: `0 0 15px var(--color-secondary-accent), 0 0 5px var(--color-secondary-accent) inset`,
                                animation: 'pulse 2s infinite ease-in-out',
                            }}
                        />
                    );
                }
            }
        }
        return elements;
    };


    const tileWidthPercent = 100 / MAZE_COLS;
    const tileHeightPercent = 100 / MAZE_ROWS;

    return (
        <div className="w-full max-w-5xl bg-[var(--color-card-background)] border-4 md:border-8 border-[var(--color-border)] rounded-lg shadow-2xl p-2 md:p-4 relative">
             <div className="grid grid-cols-3 items-center mb-2 px-1">
                {/* Left: Home and Level */}
                <div className="flex items-center gap-2 justify-start">
                    <button
                        onClick={onReset}
                        className="bg-transparent text-white border border-[var(--color-border)] px-2 py-1 text-[10px] sm:text-xs hover:bg-[var(--color-primary-accent)] hover:text-black active:bg-[var(--color-primary-accent-darker)] flex items-center justify-center gap-1"
                    >
                        <HomeIcon className="w-3 h-3 sm:w-4 sm:h-4" />
                        <span className="hidden sm:inline">HOME</span>
                    </button>
                    <p className="text-[10px] sm:text-xs text-[var(--color-muted-foreground)] whitespace-nowrap">LVL: {currentLevelIndex + 1}</p>
                </div>
                
                {/* Center: Title */}
                <p className="text-center text-[10px] sm:text-sm text-[var(--color-primary-accent)] whitespace-nowrap">
                    ESCAPE THE DUNGEON!
                </p>

                {/* Right: Spacer to enforce centering */}
                <div />
            </div>

            <div
                className="relative maze-background overflow-hidden mx-auto w-full"
                style={{ aspectRatio: `${MAZE_COLS} / ${MAZE_ROWS}` }}
            >
                {renderMaze()}

                {/* Player */}
                <img
                    src={`data:image/png;base64,${player1.sprites[playerFrame]}`}
                    alt="Player 1"
                    className="absolute transition-all"
                    style={{
                        imageRendering: 'pixelated',
                        width: `${tileWidthPercent * 0.8}%`,
                        height: `${tileHeightPercent * 0.8}%`,
                        left: `${playerPos.col * tileWidthPercent + (tileWidthPercent * 0.1)}%`,
                        top: `${playerPos.row * tileHeightPercent + (tileHeightPercent * 0.1)}%`,
                        transitionProperty: 'left, top',
                        transitionDuration: `${GAME_SPEED}ms`,
                    }}
                />

                {/* Guards */}
                {guards.map((guard, i) => (
                    <img
                        key={i}
                        src={`data:image/png;base64,${player2.sprites[guard.frame]}`}
                        alt={`Guard ${i + 1}`}
                        className="absolute transition-all"
                        style={{
                            imageRendering: 'pixelated',
                            width: `${tileWidthPercent * 0.8}%`,
                            height: `${tileHeightPercent * 0.8}%`,
                            transform: 'scaleX(-1)',
                            left: `${guard.col * tileWidthPercent + (tileWidthPercent * 0.1)}%`,
                            top: `${guard.row * tileHeightPercent + (tileHeightPercent * 0.1)}%`,
                            transitionProperty: 'left, top',
                            transitionDuration: `${GAME_SPEED * 2}ms`,
                        }}
                    />
                ))}
            </div>
            {gameState !== 'playing' && <GameOverlay status={gameState} />}
            <MobileControls onMove={handleMobileMove} />
        </div>
    );
};

export default FightScreen;