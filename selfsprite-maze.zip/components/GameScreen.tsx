import React from 'react';

const GameScreen: React.FC = () => {
    return (
        <div>
            {/* This component is currently not in use. */}
        </div>
    );
};

export default GameScreen;
