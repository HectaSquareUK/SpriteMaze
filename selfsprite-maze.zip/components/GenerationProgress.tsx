
import React from 'react';
import { SpriteSource } from '../types';
import { ArrowRightIcon, CancelIcon } from './icons';

interface ProgressDisplayProps {
    title: string;
    progressSprites: string[];
    totalFrames: number;
    cols: number;
    fullSheet: string | null;
    source: SpriteSource;
    isComplete: boolean;
    analysisText: string | null;
}

const ProgressDisplay: React.FC<ProgressDisplayProps> = ({ title, progressSprites, totalFrames, cols, source, isComplete, analysisText }) => {
    const currentFrame = progressSprites.length;

    const isAiGenerated = source === SpriteSource.GENERATE;

    // Use specific text when AI generation is complete, otherwise show frame count.
    const statusText = isComplete && isAiGenerated
        ? "GENERATION COMPLETE!"
        : `FRAME ${Math.min(currentFrame, totalFrames)} OF ${totalFrames}`;

    return (
        <div className={`flex-1 p-6 bg-[var(--color-card-background)] rounded-lg border-2 ${isComplete ? 'border-[var(--color-secondary-accent)]' : 'border-[var(--color-border)]'}`}>
            <h2 className={`text-xl mb-2 text-center ${isComplete ? 'text-[var(--color-secondary-accent)]' : 'text-[var(--color-primary-accent)] animate-pulse'}`}>{title}</h2>
            <p className="text-[var(--color-muted-foreground)] mb-4 text-xs text-center">
                {statusText}
            </p>
            <div
                className="grid gap-2"
                style={{ gridTemplateColumns: `repeat(${cols > 0 ? cols : 3}, minmax(0, 1fr))` }}
            >
                {Array.from({ length: totalFrames }).map((_, index) => {
                    if (index < progressSprites.length) {
                        return (
                            <div key={index} className="aspect-square">
                                <img
                                    src={`data:image/png;base64,${progressSprites[index]}`}
                                    alt={`Frame ${index + 1}`}
                                    className="w-full h-full object-contain"
                                    style={{ imageRendering: 'pixelated' }}
                                 />
                            </div>
                        );
                    } else if (index === progressSprites.length && !isComplete) {
                        return (
                            <div key={index} className="aspect-square flex items-center justify-center">
                                <div className="w-1/2 h-1/2 border-2 border-dashed border-[var(--color-primary-accent)] rounded-full animate-spin"></div>
                            </div>
                        );
                    } else {
                        return <div key={index} className="aspect-square"></div>;
                    }
                })}
            </div>
            {analysisText && (
                <div className="mt-4">
                    <h3 className="text-xs text-[var(--color-muted-foreground)] mb-1 text-center">AI GRID ANALYSIS</h3>
                    <pre className="text-left bg-black text-[var(--color-secondary-accent)] p-2 rounded-md text-[10px] whitespace-pre-wrap break-all">
                        {analysisText}
                    </pre>
                </div>
            )}
        </div>
    );
};

interface GenerationProgressProps {
    p1Progress: string[];
    p1TotalFrames: number;
    p1Cols: number;
    p1FullSheet: string | null;
    p1Source: SpriteSource;
    p1AnalysisText: string | null;
    p2Progress: string[];
    p2TotalFrames: number;
    p2Cols: number;
    p2FullSheet: string | null;
    p2Source: SpriteSource;
    p2AnalysisText: string | null;
    isComplete: boolean;
    onCancel: () => void;
    onProceed: () => void;
}

const GenerationProgress: React.FC<GenerationProgressProps> = ({ 
    p1Progress, p1TotalFrames, p1Cols, p1FullSheet, p1Source, p1AnalysisText,
    p2Progress, p2TotalFrames, p2Cols, p2FullSheet, p2Source, p2AnalysisText,
    isComplete, onCancel, onProceed
}) => {
    return (
        <div className="w-full max-w-4xl text-white text-center">
             <h2 className="text-3xl mb-6 text-[var(--color-primary-accent)] animate-pulse">
                {isComplete ? "GENERATION COMPLETE!" : "GENERATING CHARACTERS..."}
            </h2>
            <div className="flex flex-col md:flex-row gap-6">
                <ProgressDisplay 
                    title="PLAYER 1" 
                    progressSprites={p1Progress} 
                    totalFrames={p1TotalFrames} 
                    cols={p1Cols}
                    fullSheet={p1FullSheet}
                    source={p1Source}
                    isComplete={isComplete}
                    analysisText={p1AnalysisText}
                />
                <ProgressDisplay 
                    title="PLAYER 2" 
                    progressSprites={p2Progress} 
                    totalFrames={p2TotalFrames}
                    cols={p2Cols}
                    fullSheet={p2FullSheet}
                    source={p2Source}
                    isComplete={isComplete}
                    analysisText={p2AnalysisText}
                />
            </div>
            <p className="text-[var(--color-muted-foreground)] mt-8 text-xs">
                AI generation takes a moment. Uploading a sprite sheet is instant. Please be patient.
            </p>
            <div className="mt-8">
                {isComplete ? (
                    <button
                        onClick={onProceed}
                        className="bg-[var(--color-secondary-accent)] text-black px-8 py-3 text-sm border-2 border-black hover:bg-[var(--color-secondary-accent-darker)] active:bg-[var(--color-secondary-accent-darker)] flex items-center justify-center gap-3"
                    >
                        NEXT <ArrowRightIcon className="w-5 h-5" />
                    </button>
                ) : (
                    <button
                        onClick={onCancel}
                        className="bg-[var(--color-destructive)] text-white px-8 py-3 text-sm border-2 border-black hover:bg-[var(--color-destructive-darker)] active:bg-[var(--color-destructive-darker)] flex items-center justify-center gap-3"
                    >
                        CANCEL GENERATION <CancelIcon className="w-5 h-5" />
                    </button>
                )}
            </div>
        </div>
    );
};

export default GenerationProgress;
