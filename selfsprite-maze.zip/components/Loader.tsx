
import React from 'react';

const Loader: React.FC = () => {
    const loadingMessages = [
        "LOADING... PLEASE WAIT",
        "GENERATING PIXEL SPRITE...",
        "ENTERING THE RING...",
        "LACING UP GLOVES...",
        "TRAINING MONTAGE...",
    ];

    const [message, setMessage] = React.useState(loadingMessages[0]);

    React.useEffect(() => {
        const interval = setInterval(() => {
            setMessage(prev => {
                const currentIndex = loadingMessages.indexOf(prev);
                const nextIndex = (currentIndex + 1) % loadingMessages.length;
                return loadingMessages[nextIndex];
            });
        }, 2000);
        return () => clearInterval(interval);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <div className="flex flex-col items-center justify-center text-white p-8">
            <div className="w-16 h-16 border-4 border-dashed border-[var(--color-primary-accent)] rounded-full animate-spin mb-6"></div>
            <p className="text-xl text-[var(--color-primary-accent)] animate-pulse">{message}</p>
        </div>
    );
};

export default Loader;