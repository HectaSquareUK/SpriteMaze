import React from 'react';
import { ChevronUpIcon, ChevronDownIcon, ChevronLeftIcon, ChevronRightIcon } from './icons';

export type MoveDirection = 'up' | 'down' | 'left' | 'right';

interface MobileControlsProps {
    onMove: (direction: MoveDirection) => void;
}

const MobileControls: React.FC<MobileControlsProps> = ({ onMove }) => {
    // Prevent default scroll behavior on touch
    const handleTouchStart = (e: React.TouchEvent, direction: MoveDirection) => {
        e.preventDefault();
        onMove(direction);
    };

    const DPadButton: React.FC<{
        direction: MoveDirection,
        children: React.ReactNode,
        className?: string,
    }> = ({ direction, children, className }) => (
        <button
            onTouchStart={(e) => handleTouchStart(e, direction)}
            onMouseDown={(e) => { // Fallback for desktop testing
                e.preventDefault();
                onMove(direction);
            }}
            className={`w-full h-full bg-slate-800/70 text-white active:bg-slate-600/70 flex items-center justify-center transition-colors ${className}`}
            aria-label={`Move ${direction}`}
        >
            {children}
        </button>
    );

    return (
        // Use xl:hidden to show on mobile and tablets, but hide on extra-large desktops
        // Smaller size, semi-transparent background applied to each button.
        <div className="fixed bottom-4 right-4 z-30 xl:hidden">
            <div className="grid grid-cols-3 grid-rows-3 w-32 h-32 sm:w-40 sm:h-40 shadow-lg">
                <div className="col-start-2 rounded-t-lg">
                    <DPadButton direction="up" className="rounded-t-lg">
                        <ChevronUpIcon className="w-6 h-6 sm:w-8 sm:h-8" />
                    </DPadButton>
                </div>
                <div className="col-start-1 rounded-l-lg">
                    <DPadButton direction="left" className="rounded-l-lg">
                        <ChevronLeftIcon className="w-6 h-6 sm:w-8 sm:h-8" />
                    </DPadButton>
                </div>
                {/* Center piece */}
                <div className="col-start-2 bg-slate-800/70" />
                <div className="col-start-3 rounded-r-lg">
                    <DPadButton direction="right" className="rounded-r-lg">
                        <ChevronRightIcon className="w-6 h-6 sm:w-8 sm:h-8" />
                    </DPadButton>
                </div>
                <div className="col-start-2 rounded-b-lg">
                    <DPadButton direction="down" className="rounded-b-lg">
                        <ChevronDownIcon className="w-6 h-6 sm:w-8 sm:h-8" />
                    </DPadButton>
                </div>
            </div>
        </div>
    );
};

export default MobileControls;