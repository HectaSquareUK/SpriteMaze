

import React, { useState, useRef, useEffect } from 'react';
import { UploadIcon, CameraIcon, PlayIcon, ArrowRightIcon, BackIcon } from './icons';
import { CHARACTER_TYPES, MOTION_TYPES, MotionType, SpriteSource, IPlayerConfig, GENDER_TYPES, GenderType } from '../types';
import CameraModal from './CameraModal';

interface PlayerSetupScreenProps {
    playerNumber: 1 | 2;
    onComplete: (config: IPlayerConfig) => void;
    initialConfig: IPlayerConfig;
}

const PlayerSetupScreen: React.FC<PlayerSetupScreenProps> = ({ playerNumber, onComplete, initialConfig }) => {
    const [config, setConfig] = useState<IPlayerConfig>(initialConfig);
    const [step, setStep] = useState(1);
    const [isCameraOpen, setIsCameraOpen] = useState(false);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Effect to handle the initial file passed via props
    useEffect(() => {
        if (initialConfig.file) {
            setConfig(initialConfig);
        }
    }, [initialConfig]);

    // Effect for creating/revoking object URLs for previews
    useEffect(() => {
        if (!config.file) {
            if (previewUrl) {
                URL.revokeObjectURL(previewUrl);
                setPreviewUrl(null);
            }
            return;
        }
        const objectUrl = URL.createObjectURL(config.file);
        setPreviewUrl(objectUrl);
        
        return () => URL.revokeObjectURL(objectUrl);
    }, [config.file]);


    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            setConfig({ ...config, file });
        }
    };

    const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        event.stopPropagation();
        const file = event.dataTransfer.files?.[0];
        if (file && file.type.startsWith('image/')) {
            setConfig({ ...config, file });
        }
    };

    const BackButton = ({ toStep }: { toStep: number }) => (
        <button onClick={() => setStep(toStep)} className="flex items-center gap-2 text-[var(--color-muted-foreground)] hover:text-white transition-colors text-xs">
            <BackIcon className="w-4 h-4" />
            BACK
        </button>
    );

    const renderStep1 = () => (
        <div className="flex-1 p-6 bg-[var(--color-card-background)] rounded-lg border-2 border-[var(--color-border)] text-center">
            <h3 className="text-xl mb-2 text-[var(--color-primary-accent)]">STEP 1: CHOOSE YOUR METHOD</h3>
            <p className="text-[var(--color-muted-foreground)] text-xs mb-6">How do you want to create your character?</p>
            <div className="flex flex-col md:flex-row gap-4">
                <div onClick={() => { setConfig({ ...config, source: SpriteSource.GENERATE, file: null }); setStep(2); }} className="flex-1 p-6 border-2 border-[var(--color-border)] rounded-lg hover:border-[var(--color-primary-accent)] hover:bg-[var(--color-primary-accent)]/10 cursor-pointer transition-all">
                    <h4 className="text-lg text-[var(--color-foreground)] mb-2">GENERATE</h4>
                    <p className="text-xs text-[var(--color-muted-foreground)]">Use AI to turn a photo of you or a friend into a pixel art character. Requires a Gemini API key.</p>
                </div>
                 <div onClick={() => { setConfig({ ...config, source: SpriteSource.UPLOAD, file: initialConfig.file }); setStep(2); }} className="flex-1 p-6 border-2 border-[var(--color-border)] rounded-lg hover:border-[var(--color-primary-accent)] hover:bg-[var(--color-primary-accent)]/10 cursor-pointer transition-all">
                    <h4 className="text-lg text-[var(--color-foreground)] mb-2">UPLOAD</h4>
                    <p className="text-xs text-[var(--color-muted-foreground)]">Use your own sprite sheet image. A default is pre-loaded so you can play right away.</p>
                </div>
            </div>
        </div>
    );
    
    const renderStep2Generate = () => (
        <div className="flex-1 p-6 bg-[var(--color-card-background)] rounded-lg border-2 border-[var(--color-border)]">
            <div className="flex items-center mb-4">
                <div className="flex-1">
                    <BackButton toStep={1} />
                </div>
                <h3 className="flex-none text-xl text-[var(--color-primary-accent)] text-center whitespace-nowrap px-4">STEP 2: DESIGN YOUR CHARACTER</h3>
                <div className="flex-1"></div>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h3 className="text-lg mb-2 text-[var(--color-foreground)]">CHARACTER</h3>
                    <div className="grid grid-cols-2 gap-1 text-xs max-h-48 overflow-y-auto pr-2">
                        {CHARACTER_TYPES.map(char => (
                            <label key={char} className={`p-2 border rounded-md cursor-pointer transition-colors ${config.character === char ? 'bg-[var(--color-primary-accent)] border-[var(--color-primary-accent-darker)] text-black' : 'bg-transparent border-[var(--color-border)] hover:border-[var(--color-primary-accent)]'}`}>
                                <input type="radio" value={char} checked={config.character === char} onChange={() => setConfig({...config, character: char})} className="hidden" />
                                {char.toUpperCase()}
                            </label>
                        ))}
                    </div>
                </div>
                <div className="space-y-4">
                    <div>
                        <h3 className="text-lg mb-2 text-[var(--color-foreground)]">MOTION TYPE</h3>
                        <div className="relative">
                            <select 
                                value={config.motionType}
                                onChange={(e) => setConfig({...config, motionType: e.target.value as MotionType})}
                                className="w-full p-2 border rounded-md bg-transparent border-[var(--color-border)] text-white appearance-none cursor-pointer hover:border-[var(--color-primary-accent)]"
                            >
                                {MOTION_TYPES.map(motion => (
                                    <option key={motion} value={motion} className="bg-[var(--color-background)] text-white">
                                        {motion.toUpperCase()}
                                    </option>
                                ))}
                            </select>
                            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-[var(--color-muted-foreground)]">
                                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                            </div>
                        </div>
                    </div>
                    <div>
                        <h3 className="text-lg mb-2 text-[var(--color-foreground)]">GENDER</h3>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                            {GENDER_TYPES.map(gender => (
                                <label key={gender} className={`p-2 border rounded-md cursor-pointer transition-colors text-center ${config.gender === gender ? 'bg-[var(--color-primary-accent)] border-[var(--color-primary-accent-darker)] text-black' : 'bg-transparent border-[var(--color-border)] hover:border-[var(--color-primary-accent)]'}`}>
                                    <input type="radio" value={gender} checked={config.gender === gender} onChange={() => setConfig({...config, gender: gender as GenderType})} className="hidden" />
                                    {gender.toUpperCase()}
                                </label>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
            <div className="text-center mt-8">
                <button onClick={() => setStep(3)} className="bg-[var(--color-secondary-accent)] text-black px-8 py-3 text-sm border-2 border-black hover:bg-[var(--color-secondary-accent-darker)] flex items-center justify-center gap-3">
                    NEXT: PROVIDE PHOTO <ArrowRightIcon className="w-5 h-5" />
                </button>
            </div>
        </div>
    );
    
    const renderStep3Generate = () => (
        <div className="flex-1 p-6 bg-[var(--color-card-background)] rounded-lg border-2 border-[var(--color-border)]">
            <div className="flex items-center mb-4">
                <div className="flex-1">
                    <BackButton toStep={2} />
                </div>
                <h3 className="flex-none text-xl text-[var(--color-primary-accent)] text-center whitespace-nowrap px-4">STEP 3: PROVIDE A PHOTO</h3>
                <div className="flex-1"></div>
            </div>
             <p className="text-[var(--color-muted-foreground)] text-xs mb-6 text-center">The AI will use this photo as a reference to create your character.</p>
              {config.file && previewUrl ? (
                <div className="relative p-2 border-2 border-dashed bg-black rounded-md border-[var(--color-secondary-accent)] flex justify-center items-center h-48">
                    <img src={previewUrl} alt="Photo preview" className="max-w-full max-h-full object-contain rounded-sm"/>
                    <button onClick={() => setConfig({...config, file: null})} className="absolute top-1 right-1 bg-black bg-opacity-70 text-[var(--color-destructive)] rounded-full p-1 leading-none hover:bg-opacity-90 transition-colors" aria-label="Remove photo">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </div>
            ) : (
                <div className="grid grid-cols-2 gap-4">
                    <button onClick={() => fileInputRef.current?.click()} className="p-4 h-32 border-2 border-dashed bg-black rounded-md cursor-pointer hover:border-[var(--color-primary-accent)] transition-colors border-[var(--color-border)] text-center text-[var(--color-muted-foreground)] flex flex-col items-center justify-center">
                        <UploadIcon className="w-10 h-10 mx-auto mb-2" />
                        <p className="text-xs">UPLOAD FILE</p>
                        <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
                    </button>
                    <button onClick={() => setIsCameraOpen(true)} className="p-4 h-32 border-2 border-dashed bg-black rounded-md cursor-pointer hover:border-[var(--color-primary-accent)] transition-colors border-[var(--color-border)] text-center text-[var(--color-muted-foreground)] flex flex-col items-center justify-center">
                        <CameraIcon className="w-10 h-10 mx-auto mb-2" />
                        <p className="text-xs">USE CAMERA</p>
                    </button>
                </div>
            )}
             <div className="text-center mt-8">
                <button
                    onClick={() => onComplete(config)}
                    disabled={!config.file}
                    className="bg-[var(--color-secondary-accent)] text-black px-10 py-4 text-xl border-2 border-black hover:bg-[var(--color-secondary-accent-darker)] active:bg-[var(--color-secondary-accent-darker)] disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                >
                    {playerNumber === 1 ? 'NEXT: SETUP PLAYER 2' : 'PROCESS & START GAME'}
                    {playerNumber === 1 ? <ArrowRightIcon className="w-6 h-6" /> : <PlayIcon className="w-6 h-6" />}
                </button>
            </div>
        </div>
    );
    
    const renderStep2Upload = () => (
        <div className="flex-1 p-6 bg-[var(--color-card-background)] rounded-lg border-2 border-[var(--color-border)]">
            <div className="flex items-center mb-4">
                <div className="flex-1">
                    <BackButton toStep={1} />
                </div>
                <h3 className="flex-none text-xl text-[var(--color-primary-accent)] text-center whitespace-nowrap px-4">STEP 2: UPLOAD SPRITE SHEET</h3>
                <div className="flex-1"></div>
            </div>
             <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                    <h3 className="text-lg mb-2 text-[var(--color-foreground)]">GRID DIMENSIONS</h3>
                    <div className="flex gap-4">
                        <div className="flex-1">
                            <label className="text-xs text-[var(--color-muted-foreground)]">COLUMNS</label>
                            <input type="number" min="1" max="20" value={config.spriteSheetCols} onChange={(e) => setConfig({...config, spriteSheetCols: parseInt(e.target.value, 10) || 1 })} className="w-full p-2 border rounded-md bg-transparent border-[var(--color-border)] text-white hover:border-[var(--color-primary-accent)]" />
                        </div>
                        <div className="flex-1">
                            <label className="text-xs text-[var(--color-muted-foreground)]">ROWS</label>
                            <input type="number" min="1" max="20" value={config.spriteSheetRows} onChange={(e) => setConfig({...config, spriteSheetRows: parseInt(e.target.value, 10) || 1 })} className="w-full p-2 border rounded-md bg-transparent border-[var(--color-border)] text-white hover:border-[var(--color-primary-accent)]" />
                        </div>
                    </div>
                </div>
                <div>
                    <h3 className="text-lg mb-2 text-[var(--color-foreground)]">SPRITE SHEET</h3>
                    <div className={`p-2 border-2 border-dashed bg-black rounded-md cursor-pointer hover:border-[var(--color-primary-accent)] transition-colors h-[100px] ${config.file ? 'border-[var(--color-secondary-accent)]' : 'border-[var(--color-border)]'}`} onClick={() => fileInputRef.current?.click()} onDrop={handleDrop} onDragOver={(e) => e.preventDefault()}>
                        <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/png, image/jpeg" className="hidden" />
                        {config.file && previewUrl ? (
                            <div className="w-full h-full flex flex-col items-center justify-center text-center">
                                <img src={previewUrl} alt="Sprite sheet preview" className="max-w-full max-h-[65%]" style={{ imageRendering: 'pixelated' }} />
                                <div className="mt-auto">
                                    <p className="text-[var(--color-secondary-accent)] text-xs truncate">{config.file.name}</p>
                                    <p className="text-[var(--color-muted-foreground)] text-[10px]">(Click to change)</p>
                                </div>
                            </div>
                        ) : (
                            <div className="text-center text-[var(--color-muted-foreground)] pt-5">
                                <UploadIcon className="w-8 h-8 mx-auto mb-1" />
                                <p className="text-xs">DRAG OR CLICK</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            <p className="text-xs text-[var(--color-muted-foreground)] mt-2">Upload a sprite sheet organized in a grid (left-to-right, top-to-bottom).</p>
            <div className="text-center mt-8">
                 <button
                    onClick={() => onComplete(config)}
                    disabled={!config.file}
                    className="bg-[var(--color-secondary-accent)] text-black px-10 py-4 text-xl border-2 border-black hover:bg-[var(--color-secondary-accent-darker)] active:bg-[var(--color-secondary-accent-darker)] disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                >
                    {playerNumber === 1 ? 'NEXT: SETUP PLAYER 2' : 'PROCESS & START GAME'}
                    {playerNumber === 1 ? <ArrowRightIcon className="w-6 h-6" /> : <PlayIcon className="w-6 h-6" />}
                </button>
            </div>
        </div>
    );

    const renderCurrentStep = () => {
        switch (step) {
            case 1: return renderStep1();
            case 2:
                return config.source === SpriteSource.GENERATE ? renderStep2Generate() : renderStep2Upload();
            case 3:
                 return config.source === SpriteSource.GENERATE ? renderStep3Generate() : null; // Should not reach here in upload flow
            default: return renderStep1();
        }
    };

    return (
        <div className="w-full max-w-2xl text-[var(--color-foreground)]">
            <div className="text-center mb-4">
                <h2 className="text-3xl text-[var(--color-primary-accent)]">SETUP PLAYER {playerNumber}</h2>
                <p className="text-[var(--color-muted-foreground)] text-xs">
                    {playerNumber === 1 ? "This character will be your hero in the maze." : "This character's design will become the enemy guards!"}
                </p>
            </div>
            {renderCurrentStep()}
            {isCameraOpen && (
                <CameraModal
                    onClose={() => setIsCameraOpen(false)}
                    onPhotoTaken={(file) => {
                        setConfig({ ...config, file, source: SpriteSource.GENERATE });
                        setIsCameraOpen(false);
                    }}
                />
            )}
        </div>
    );
};

export default PlayerSetupScreen;
