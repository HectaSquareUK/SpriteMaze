import React, { useState, useEffect } from 'react';

interface PreGameShowcaseProps {
    p1Sprites: string[];
    p2Sprites: string[];
    onComplete: () => void;
}

// New component for the loading bar
const LoadingBar: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
    const [progress, setProgress] = useState(0);

    useEffect(() => {
        // Start animation shortly after component mounts
        const timer = setTimeout(() => setProgress(100), 100); 
        // Set a timer for the total duration of the showcase
        const completeTimer = setTimeout(onComplete, 4000); 

        return () => {
            clearTimeout(timer);
            clearTimeout(completeTimer);
        };
    }, [onComplete]);

    return (
        <div className="w-full max-w-md bg-black border-2 border-[var(--color-border)] rounded-full p-1 mt-8">
            <div
                className="h-4 bg-[var(--color-secondary-accent)] rounded-full transition-all duration-[3800ms] ease-linear"
                style={{ width: `${progress}%` }}
            ></div>
        </div>
    );
};

const PreGameShowcase: React.FC<PreGameShowcaseProps> = ({ p1Sprites, p2Sprites, onComplete }) => {
    
    const SpriteDisplay: React.FC<{ sprites: string[], reversed?: boolean }> = ({ sprites, reversed }) => {
        const [frame, setFrame] = useState(0);
        useEffect(() => {
            if (sprites.length === 0) return;
            const interval = setInterval(() => {
                setFrame(f => (f + 1) % sprites.length);
            }, 150);
            return () => clearInterval(interval);
        }, [sprites]);
        
        if (sprites.length === 0) return <div className="w-48 h-48 bg-black/20" />;

        return (
             <img 
                src={`data:image/png;base64,${sprites[frame]}`} 
                alt="Player sprite"
                className="h-48 object-contain"
                style={{ 
                    imageRendering: 'pixelated',
                    transform: reversed ? 'scaleX(-1)' : 'none'
                }}
            />
        );
    };

    return (
        <div className="w-full max-w-4xl text-center p-8 text-white flex flex-col items-center">
            <div className="flex justify-around items-center w-full">
                {/* Player 1 */}
                <div className="flex flex-col items-center">
                    <h2 className="text-3xl mb-4 text-[var(--color-primary-accent)]">PLAYER 1</h2>
                    <SpriteDisplay sprites={p1Sprites} />
                </div>

                {/* VS Text */}
                <div className="text-6xl font-bold text-[var(--color-secondary-accent)] animate-pulse">
                    VS
                </div>

                {/* Player 2 */}
                <div className="flex flex-col items-center">
                    <h2 className="text-3xl mb-4 text-[var(--color-primary-accent)]">PLAYER 2</h2>
                     <SpriteDisplay sprites={p2Sprites} reversed />
                </div>
            </div>

            <LoadingBar onComplete={onComplete} />
        </div>
    );
};

export default PreGameShowcase;