
import { GoogleGenAI, Modality, Type } from "@google/genai";
import { CharacterType, MotionType, GenderType } from "../types";
import { base64ToFile, sliceSpriteSheet } from "./imageService";
import { getGenerationPrompt, getAnalysisPrompt } from "./promptService";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generateCharacterAnimation = async (
    base64Image: string,
    mimeType: string,
    gender: GenderType,
    characterType: CharacterType,
    motionType: MotionType,
    frameCount: number, // This parameter is now ignored but kept for signature compatibility.
    onProgress: (sprites: string[]) => void,
    signal: AbortSignal
): Promise<{ fullSheet: string; sprites: string[]; cols: number; rows: number; analysisText: string; }> => {
    try {
        const generationModel = 'gemini-2.5-flash-image-preview';
        
        if (signal.aborted) {
            const error = new Error("Generation cancelled by user.");
            error.name = "AbortError";
            throw error;
        }

        const generationPrompt = getGenerationPrompt(gender, characterType, motionType);
        
        // --- Step 1: Generate the sprite sheet image ---
        const response = await ai.models.generateContent({
            model: generationModel,
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Image,
                            mimeType: mimeType,
                        },
                    },
                    { text: generationPrompt },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });

        if (signal.aborted) {
            console.log("Generation finished but was cancelled. Ignoring results.");
            const error = new Error("Generation cancelled by user.");
            error.name = "AbortError";
            throw error;
        }

        const imagePart = response.candidates?.[0]?.content?.parts?.find(part => part.inlineData);
        
        if (imagePart && imagePart.inlineData) {
            const spriteSheetBase64 = imagePart.inlineData.data;
            
            // --- Step 2: Analyze the generated image to get grid dimensions ---
            const analysisModel = 'gemini-2.5-flash';
            const analysisResponse = await ai.models.generateContent({
                model: analysisModel,
                contents: {
                    parts: [
                        {
                            inlineData: {
                                data: spriteSheetBase64,
                                mimeType: "image/png",
                            },
                        },
                        { text: getAnalysisPrompt() },
                    ]
                },
                config: {
                    responseMimeType: 'application/json',
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            columns: { type: Type.INTEGER },
                            rows: { type: Type.INTEGER }
                        },
                        required: ["columns", "rows"]
                    }
                }
            });

            let cols = 3;
            let rows = 3;
            const analysisText = analysisResponse.text;

            try {
                const gridInfo = JSON.parse(analysisText);
                if (gridInfo.columns && gridInfo.rows) {
                    cols = parseInt(gridInfo.columns, 10);
                    rows = parseInt(gridInfo.rows, 10);
                }
            } catch (e) {
                console.warn("Could not parse grid dimensions from AI analysis, defaulting to 3x3.", e);
            }

            const spriteSheetFile = base64ToFile(spriteSheetBase64, "generated_sheet.png", "image/png");
            const slicedSprites = await sliceSpriteSheet(spriteSheetFile, cols, rows);

            onProgress(slicedSprites);
            
            return { fullSheet: spriteSheetBase64, sprites: slicedSprites, cols, rows, analysisText };

        } else {
            console.error("Gemini API Response:", JSON.stringify(response, null, 2));
            throw new Error('AI failed to generate the sprite sheet.');
        }

    } catch (error) {
        // Re-throw the error to be handled by the caller
        throw error;
    }
};
