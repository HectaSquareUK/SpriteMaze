import { IPlayerConfig, SpriteSource } from '../types';

/**
 * Creates a GIF from a series of base64 encoded sprite images,
 * zips it along with individual frames, and initiates a download.
 * @param sprites An array of base64 encoded PNG strings (without the data URL prefix).
 * @param config The player configuration object, used for naming the downloaded file.
 * @throws An error if required libraries are missing or if image processing fails.
 */
export const createAndDownloadGifZip = async (sprites: string[], config: IPlayerConfig): Promise<void> => {
    // These libraries are loaded via CDN in index.html
    const JSZip = (window as any).JSZip;
    const GIF = (window as any).GIF;

    if (!JSZip || !GIF) {
        throw new Error("A required library (JSZip or GIF.js) is missing. Please check the page setup.");
    }

    if (sprites.length === 0) {
        console.warn("No sprites provided to create a GIF.");
        return;
    }

    // --- START: NEW CODE to bypass CSP ---
    // 1. Fetch the worker script's text content
    const workerResponse = await fetch('https://cdnjs.cloudflare.com/ajax/libs/gif.js/0.2.0/gif.worker.js');
    if (!workerResponse.ok) {
        throw new Error(`Failed to fetch GIF worker script: ${workerResponse.statusText}`);
    }
    const workerScriptText = await workerResponse.text();

    // 2. Create a local Blob from the text
    const workerBlob = new Blob([workerScriptText], { type: 'application/javascript' });

    // 3. Create a same-origin URL for the Blob
    const workerUrl = URL.createObjectURL(workerBlob);
    // --- END: NEW CODE ---

    const imagePromises = sprites.map(base64 => {
        return new Promise<HTMLImageElement>((resolve, reject) => {
            const img = new Image();
            img.src = `data:image/png;base64,${base64}`;
            img.onload = () => resolve(img);
            img.onerror = () => reject(new Error('Failed to load a sprite image for GIF creation.'));
        });
    });

    const images = await Promise.all(imagePromises);
    const { width, height } = images[0];
    
    // Initialize GIF encoder
    const gif = new GIF({
        workers: 2,
        quality: 10,
        width,
        height,
        workerScript: workerUrl, // 4. Use the local Blob URL
        background: '#fff', // Explicitly set background to white
    });

    images.forEach(img => gif.addFrame(img, { delay: 150 }));

    // Await GIF rendering
    const gifBlob: Blob = await new Promise(resolve => {
        gif.on('finished', (blob: Blob) => resolve(blob));
        gif.render();
    });

    // --- Clean up the Blob URL to prevent memory leaks ---
    URL.revokeObjectURL(workerUrl);

    // Prepare files for zipping (rest of the code is the same)
    const zip = new JSZip();
    const safeCharType = config.source === SpriteSource.GENERATE ? config.character.replace(/ /g, '_') : 'Custom_Character';
    const safeMotionType = config.source === SpriteSource.GENERATE ? config.motionType.replace(/ /g, '_') : 'Uploaded';
    const fileNameBase = `${safeCharType}_${safeMotionType}`;
    
    zip.file(`${fileNameBase}_animation.gif`, gifBlob);
    
    const framesFolder = zip.folder('frames');
    if (framesFolder) {
        sprites.forEach((base64, i) => {
            framesFolder.file(`frame_${String(i + 1).padStart(2, '0')}.png`, base64, { base64: true });
        });
    }
    
    const zipBlob = await zip.generateAsync({ type: 'blob' });
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(zipBlob);
    link.download = `${fileNameBase}_sprites.zip`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
};