// The AI-based background removal library is no longer used, as it was unreliable for pixel art.
// import { removeBackground } from '@imgly/background-removal';

export const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const result = reader.result as string;
            // Return only the base64 part, without the data URL prefix
            resolve(result.split(',')[1]);
        };
        reader.onerror = error => reject(error);
    });
};

export const base64ToFile = (base64: string, filename: string, mimeType: string): File => {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: mimeType });
    return new File([blob], filename, { type: mimeType });
};

/**
 * Removes the background from an image using a color key method.
 * It samples the colors from the four corners of the image to identify
 * background color(s) and makes all pixels of a similar color transparent.
 * This is effective for solid backgrounds and two-color checkerboard patterns.
 * @param image The source image element.
 * @returns An HTMLCanvasElement containing the image with a transparent background.
 */
const removeBackgroundWithColorKey = (image: HTMLImageElement): HTMLCanvasElement => {
    const canvas = document.createElement('canvas');
    canvas.width = image.width;
    canvas.height = image.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
        console.warn("Could not get canvas context for background removal.");
        // Return canvas with original image if context fails
        ctx?.drawImage(image, 0, 0);
        return canvas;
    }

    ctx.drawImage(image, 0, 0);
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;

    // If the top-left pixel is already fully transparent, assume the background is already handled.
    if (data[3] === 0) {
        return canvas;
    }

    const getPixel = (x: number, y: number): { r: number, g: number, b: number } | null => {
        const i = (y * canvas.width + x) * 4;
        if (i < 0 || i >= data.length) return null;
        return { r: data[i], g: data[i + 1], b: data[i + 2] };
    };

    const cornerColors = new Set<string>();
    const corners = [
        { x: 0, y: 0 },
        { x: canvas.width - 1, y: 0 },
        { x: 0, y: canvas.height - 1 },
        { x: canvas.width - 1, y: canvas.height - 1 }
    ];

    for (const corner of corners) {
        const color = getPixel(corner.x, corner.y);
        if (color) {
            cornerColors.add(`${color.r},${color.g},${color.b}`);
        }
    }
    
    const bgColors = Array.from(cornerColors).map(s => {
        const [r, g, b] = s.split(',').map(Number);
        return { r, g, b };
    });
    
    // A small tolerance to handle anti-aliasing or compression artifacts
    const tolerance = 20;

    for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        
        for (const bgColor of bgColors) {
            const distance = Math.sqrt(
                Math.pow(r - bgColor.r, 2) +
                Math.pow(g - bgColor.g, 2) +
                Math.pow(b - bgColor.b, 2)
            );

            if (distance < tolerance) {
                // Set alpha to 0 to make it transparent
                data[i + 3] = 0;
                break; // Move to next pixel
            }
        }
    }

    ctx.putImageData(imageData, 0, 0);
    return canvas;
};

export const sliceSpriteSheet = async (file: File, cols: number, rows: number): Promise<string[]> => {
    try {
        if (cols <= 0 || rows <= 0) {
            throw new Error("Column and row counts must be positive numbers.");
        }

        // Step 1: Load the original image from the file
        const originalImg = await new Promise<HTMLImageElement>((resolve, reject) => {
            const imageUrl = URL.createObjectURL(file);
            const image = new Image();
            image.onload = () => {
                URL.revokeObjectURL(imageUrl);
                resolve(image);
            };
            image.onerror = () => {
                URL.revokeObjectURL(imageUrl);
                reject(new Error("Failed to load sprite sheet image for slicing."));
            };
            image.src = imageUrl;
        });
        
        // Step 2: Remove the background.
        // The AI-based background removal was unreliable for pixel art.
        // It's replaced with a simpler "color key" method that removes the color
        // of the top-left pixel, a standard practice for sprite sheets.
        const imgCanvas = removeBackgroundWithColorKey(originalImg);
        
        // Step 3: Slice the image into frames from the processed canvas
        const frameCount = cols * rows;
        const singleFrameWidth = imgCanvas.width / cols;
        const singleFrameHeight = imgCanvas.height / rows;

        const rawSprites: string[] = [];

        const sliceCanvas = document.createElement('canvas');
        const ctx = sliceCanvas.getContext('2d');
        if (!ctx) {
            throw new Error("Could not get canvas context for slicing.");
        }

        sliceCanvas.width = singleFrameWidth;
        sliceCanvas.height = singleFrameHeight;

        for (let i = 0; i < frameCount; i++) {
            const rowIndex = Math.floor(i / cols);
            const colIndex = i % cols;
            const sourceX = colIndex * singleFrameWidth;
            const sourceY = rowIndex * singleFrameHeight;

            ctx.clearRect(0, 0, sliceCanvas.width, sliceCanvas.height);
            ctx.drawImage(
                imgCanvas,
                sourceX, // source x
                sourceY, // source y
                singleFrameWidth, // source width
                singleFrameHeight, // source height
                0, // destination x
                0, // destination y
                singleFrameWidth, // destination width
                singleFrameHeight // destination height
            );
            const dataUrl = sliceCanvas.toDataURL('image/png');
            // Get just the base64 part of the data URL
            rawSprites.push(dataUrl.split(',')[1]);
        }

        return rawSprites;
    } catch (error) {
        throw new Error(`Failed during background removal or slicing:\n${error instanceof Error ? error.message : String(error)}`);
    }
};