import { Level, Position } from '../types';

// --- CONSTANTS ---
const MAZE_WIDTH = 21; // Must be an odd number
const MAZE_HEIGHT = 11; // Must be an odd number
const MIN_GUARD_DISTANCE = 10; // Min path distance from player start
const PATROL_PATH_LENGTH = 4; // Length of a guard's random patrol path

// --- HELPER FUNCTIONS ---

/**
 * Shuffles an array in place.
 * @param array The array to shuffle.
 */
const shuffle = <T>(array: T[]): T[] => {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
};

/**
 * Generates a maze using Randomized Depth-First Search.
 * @returns A 2D number array representing the maze layout (0=path, 1=wall).
 */
const createMaze = (): number[][] => {
    // Initialize grid with walls
    const maze = Array.from({ length: MAZE_HEIGHT }, () => Array(MAZE_WIDTH).fill(1));
    const stack: Position[] = [{ row: 1, col: 1 }];
    maze[1][1] = 0; // Start point

    const carve = (pos: Position) => {
        maze[pos.row][pos.col] = 0;
        const neighbors = shuffle([
            { row: pos.row - 2, col: pos.col },
            { row: pos.row + 2, col: pos.col },
            { row: pos.row, col: pos.col - 2 },
            { row: pos.row, col: pos.col + 2 },
        ]);

        for (const neighbor of neighbors) {
            const { row, col } = neighbor;
            if (row > 0 && row < MAZE_HEIGHT - 1 && col > 0 && col < MAZE_WIDTH - 1 && maze[row][col] === 1) {
                // Carve wall between current and neighbor
                maze[pos.row + (row - pos.row) / 2][pos.col + (col - pos.col) / 2] = 0;
                carve(neighbor);
            }
        }
    };

    carve({ row: 1, col: 1 });
    return maze;
};

/**
 * Uses Breadth-First Search to calculate path distances from a start point.
 * @returns A 2D number array where each cell value is its distance from the start.
 */
const calculateDistances = (start: Position, maze: number[][]): number[][] => {
    const distances = Array.from({ length: MAZE_HEIGHT }, () => Array(MAZE_WIDTH).fill(Infinity));
    const queue: { pos: Position, dist: number }[] = [{ pos: start, dist: 0 }];
    distances[start.row][start.col] = 0;

    while (queue.length > 0) {
        const { pos, dist } = queue.shift()!;
        const neighbors = [
            { row: pos.row - 1, col: pos.col },
            { row: pos.row + 1, col: pos.col },
            { row: pos.row, col: pos.col - 1 },
            { row: pos.row, col: pos.col + 1 },
        ];

        for (const neighbor of neighbors) {
            const { row, col } = neighbor;
            if (row >= 0 && row < MAZE_HEIGHT && col >= 0 && col < MAZE_WIDTH &&
                maze[row][col] !== 1 && distances[row][col] === Infinity) {
                distances[row][col] = dist + 1;
                queue.push({ pos: neighbor, dist: dist + 1 });
            }
        }
    }
    return distances;
};

/**
 * Generates random patrol paths for guards.
 */
const generateGuardPatrols = (spawnPoints: Position[], maze: number[][]): Position[][] => {
    return spawnPoints.map(startPos => {
        const path: Position[] = [startPos];
        let currentPos = startPos;
        for (let i = 0; i < PATROL_PATH_LENGTH; i++) {
            const neighbors = shuffle([
                { row: currentPos.row - 1, col: currentPos.col },
                { row: currentPos.row + 1, col: currentPos.col },
                { row: currentPos.row, col: currentPos.col - 1 },
                { row: currentPos.row, col: currentPos.col + 1 },
            ]).filter(n => maze[n.row]?.[n.col] === 0); // Only valid path neighbors

            if (neighbors.length > 0) {
                currentPos = neighbors[0]; // Pick a random valid direction
                path.push(currentPos);
            } else {
                break; // No valid moves, end path here
            }
        }
        // Create a back-and-forth patrol from the generated path
        const returnPath = [...path].reverse().slice(1);
        return [...path, ...returnPath];
    });
};

/**
 * Main function to generate a complete, new level.
 * @param levelIndex The current level number, used to scale difficulty.
 * @returns A Level object.
 */
export const generateLevel = (levelIndex: number): Level => {
    // 1. Create the maze structure
    const maze = createMaze();
    const startPos: Position = { row: 1, col: 1 };
    const endPos: Position = { row: MAZE_HEIGHT - 2, col: MAZE_WIDTH - 2 };
    maze[startPos.row][startPos.col] = 2; // Mark start
    maze[endPos.row][endPos.col] = 3;   // Mark exit

    // 2. Calculate distances from player start for safe guard spawning
    const distances = calculateDistances(startPos, maze);

    // 3. Find all valid spawn points for guards
    const validSpawnPoints: Position[] = [];
    for (let r = 0; r < MAZE_HEIGHT; r++) {
        for (let c = 0; c < MAZE_WIDTH; c++) {
            if (maze[r][c] === 0 && distances[r][c] >= MIN_GUARD_DISTANCE) {
                validSpawnPoints.push({ row: r, col: c });
            }
        }
    }

    // 4. Determine number of guards and select spawn points
    const numGuards = Math.min(2 + Math.floor(levelIndex / 2), validSpawnPoints.length);
    const guardSpawnPoints = shuffle(validSpawnPoints).slice(0, numGuards);

    // 5. Generate patrol paths for the selected guards
    const guardPatrols = generateGuardPatrols(guardSpawnPoints, maze);

    return {
        maze,
        guards: guardPatrols,
    };
};
