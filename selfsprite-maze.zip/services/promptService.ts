
import { CharacterType, MotionType, GenderType } from '../types';

/**
 * Generates the prompt for the AI to create a character sprite sheet.
 * @param gender The gender of the character.
 * @param characterType The type of character to generate (e.g., 'Wizard').
 * @param motionType The type of motion to animate (e.g., 'Walking').
 * @returns A structured string prompt for the Gemini API.
 */
export const getGenerationPrompt = (gender: GenderType, characterType: CharacterType, motionType: MotionType): string => {
    return `Generate a single, full-body, 8-bit pixel art sprite sheet of a ${gender} ${characterType}, based on the person in the provided photo in a 3x3 matrix sprite sheet. The sprite's face and physique MUST be a direct pixel art representation of the person in the photo. DO NOT change their facial features, hairstyle, or distinct characteristics. The goal is to accurately translate the person into the chosen character type, not to create a generic character. Each frame must show a distinct posture for a cohesive ${motionType} animation. Render each sprite to maximize its size within its grid cell without overlapping. The background of the entire image MUST be white.`;
};

/**
 * Generates the prompt for the AI to analyze a sprite sheet image.
 * @returns A string prompt for the Gemini API.
 */
export const getAnalysisPrompt = (): string => {
    return `Analyze the provided sprite sheet image. It contains a grid of animation frames. Determine the number of columns and rows in the grid. Respond ONLY with a JSON object containing "columns" and "rows". For example: {"columns": 3, "rows": 3}`;
};
