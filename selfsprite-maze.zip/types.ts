export enum AppState {
  INSTRUCTIONS,
  SETUP_P1,
  SETUP_P2,
  GENERATING,
  PRE_GAME_SHOWCASE,
  FIGHT_SCREEN,
  ERROR,
}

export const GENDER_TYPES = [
  'Male',
  'Female',
] as const;

export type GenderType = typeof GENDER_TYPES[number];

export const CHARACTER_TYPES = [
  'Devil',
  'Wizard',
  'Space Marine',
  'Pirate',
  'Cyberpunk',
  'Detective',
  'Jungle Explorer',
  'Boxer',
  'Vampire',
  'Superhero',
] as const;

export type CharacterType = typeof CHARACTER_TYPES[number];

export const MOTION_TYPES = [
  'Walking',
  'Running',
  'Dancing',
  'Jumping',
  'Fighting',
  'Casting Spell',
  'Cheering',
  'Waving',
  'Idle',
  'Defeated',
] as const;

export type MotionType = typeof MOTION_TYPES[number];

export const FRAME_COUNT_OPTIONS = [4, 6, 8, 10] as const;
export type FrameCount = typeof FRAME_COUNT_OPTIONS[number];

export enum SpriteSource {
  GENERATE,
  UPLOAD,
}

export interface IPlayerConfig {
    source: SpriteSource;
    file: File | null;
    // For generation
    gender: GenderType;
    character: CharacterType;
    motionType: MotionType;
    frameCount: FrameCount;
    // For upload
    spriteSheetCols: number;
    spriteSheetRows: number;
}

// --- Game Level Interfaces ---

export interface Position {
    row: number;
    col: number;
}

export interface Level {
    maze: number[][]; // 0=Path, 1=Wall, 2=Start, 3=Exit
    guards: Position[][]; // Each inner array is a patrol path for one guard
}
